It kinda works 
// well i added stuf to make transperent background for cutycapt but still
//remains problem about make cutycapt global
/


0. Need install adition libs if you do not know them then go to step 2
1. run command $ qmake
2. run $ make
Probably compiler will show what it do not see some headers
well find them and install on machine :P

btw I marked my code parts with comment // rtu student